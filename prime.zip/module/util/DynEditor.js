
export function attachEditor(element){
    console.log(element);
};
