export class PrimeSettingsManager {
	static addSettings()
	{
		// Store the version at the time of world creation
		// we do this in the migration manager.
		//const currentVersion = game.system.data.version;
		// game.settings.register("prime", "notAutoIncrementedBeforeICanCheckItWorldVersionNumber", {
		// 	name: "System Migration Version",
		// 	scope: "world",
		// 	config: false,
		// 	type: String,
		// 	default: ""
		// });
	}
}